<?php

require_once dirname(__FILE__) . "/authorize.net-1.8.1/autoload.php";