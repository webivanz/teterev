<style type="text/css">
  .btnprover {
      background: linear-gradient(to bottom, #3cb0fd, #3498db) repeat scroll 0 0 #3cb0fd;
      border-radius: 3px;
      color: #ffffff;
      font-family: Georgia;
      font-size: 15px;
      padding: 8px 15px;
      text-decoration: none;
  }
</style>
<div class="wrapper">
  <div class="wrap" style="float:left; width:100%;">
    <div id="icon-options-general" class="icon32"></div>
    <div style="width:70%;float:left;"><h2>WP Quick Booking Manager Pro</h2></div>
       <div class="main_div">
        <div class="metabox-holder" style="width:98%; float:left;">
            <div id="namediv" class="stuffbox" style="width:60%;min-height:450px;">
              <h3 class="top_bar">More Features Available in Our Pro Version:-</h3>
              <div style="padding-top:15px;margin-left:20px;">
                <a class="btnprover" target="_blank" href="http://wordpress-expert.codeinterest.com/wordpress/wp-quick-booking-manager-pro" style="width:100px;height: 20px;background-color: green;color:white;" >WP Quick Booking Manager Pro</a>
              </div>  
               <form id="frmCssFix" action="" method="post" style="width:100%">
                 <div style="margin: 20px;">
                    <ol>
                      <li>Free Installation Service</li>
                      <li>Unlimited Room and Property categories</li>
                      <li>Integrated Payment Gateways.</li>
                      <li>Built in Shopping Cart Enabled</li>
                      <li>Custom made dynamic Monthly Calendar</li>
                      <li>All Rooms Monthly Booking At a glance</li>
                      <li>Personalized Calendar User Interface</li>
                      <li>Manage Booking Straight From the Custom Made Calendar</li>
                      <li>Dynamic Rooms Gallery</li>
                      <li>Full Technical Support From Us</li>
                    </ol>
                   <div style="padding-top:15px;">
                     <b>Please Have Our Professional Version to Increase your Business </b><br/><br/><br/>
                     <a class="btnprover" target="_blank" href="http://wordpress-expert.codeinterest.com/wordpress/wp-quick-booking-manager-pro" style="width:100px;height: 20px;background-color: green;color:white;" >WP Quick Booking Manager Pro</a>
                    </div>
                   <div style="float:right;padding-top:35px; font-size: 11px;">Developed by: <a target="_blank" href="http://www.solvercircle.com">SolverCircle Ltd</a></div>
                 </div> 
               </form>	 
            </div>
         </div>
       </div>  
  </div>
</div>